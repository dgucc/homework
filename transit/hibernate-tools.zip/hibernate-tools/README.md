# Reverse engineering from a database
[hibernate-tools](https://hibernate.org/tools/)


## Setup 

1. pom.xml   

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>org.bar</groupId>
    <artifactId>foo</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <java.version>17</java.version>
        <hibernate.version>7.3.0.Final</hibernate.version>
        <h2.version>2.3.232</h2.version>
        <db2.version>db2jcc4</db2.version>
        <hsqldb.version>2.7.2</hsqldb.version>
    </properties>

    <dependencies>        
    </dependencies>
    
    <build>
        <plugins>   
            <plugin>
                <groupId>org.hibernate.tool</groupId>
                <artifactId>hibernate-tools-maven</artifactId>
                <version>${hibernate.version}</version>
                <dependencies>
                    <dependency>
                        <groupId>org.hibernate.tool</groupId>
                        <artifactId>hibernate-tools-orm</artifactId>
                        <version>${hibernate.version}</version>
                    </dependency>
                    <!-- DB2 -->
                    <dependency>
                        <groupId>com.ibm.db2.jcc</groupId>
                        <artifactId>db2jcc</artifactId>
                        <version>db2jcc4</version>
                    </dependency>
                </dependencies>
                <executions>
                    <execution>
                        <id>generate-entities</id>
                        <phase>generate-sources</phase>
                        <goals>
                            <goal>hbm2java</goal>
                        </goals>
                        <configuration>
                            <ejb3>true</ejb3>
                            <jdk5>true</jdk5>
                            <revengFile>src/main/resources/hibernate.reveng.xml</revengFile>
                        </configuration>
                    </execution>
                </executions>
            </plugin>      
        </plugins>    
    </build>    
</project>
```

To generate JPA annotations (@Entity, @Table, etc.), choose `<ejb3>true</ejb3>`


2. hibernate.properties

src/main/resources/hibernate.properties :  
```
hibernate.dialect=org.hibernate.dialect.DB2Dialect
hibernate.connection.driver_class=com.ibm.db2.jcc.DB2Driver
hibernate.connection.url=jdbc:db2://zldbfisd2.rdc.finbel.intra:51000/MATTEST:currentSchema=MEDATTEST;
hibernate.dialect=org.hibernate.dialect.DB2Dialect
hibernate.connection.username=dgucciar
hibernate.connection.password=Changed
hibernate.default_schema=MEDATTEST
hibernate.default_catalog=
hibernate.connection.autocommit=true
```


3. hibernate.reveng.xml

Customize the reverse engineering process  

src/main/resources/hibernate.reveng.xml :
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE hibernate-reverse-engineering SYSTEM "http://hibernate.org/dtd/hibernate-reverse-engineering-3.0.dtd" >

<hibernate-reverse-engineering>
    
    <schema-selection match-schema="MEDATTEST" match-table=".*" />
    
    <type-mapping>
        <sql-type jdbc-type="INTEGER" not-null="true" hibernate-type="integer" />
        <sql-type jdbc-type="INTEGER" not-null="false" hibernate-type="java.lang.Integer" />
        
        <sql-type jdbc-type="CHAR" hibernate-type="string" />
        <sql-type jdbc-type="VARCHAR" hibernate-type="string" />
        
        <sql-type jdbc-type="DATE" hibernate-type="java.time.LocalDate"/>
        <sql-type jdbc-type="TIMESTAMP" hibernate-type="java.time.LocalDateTime"/>
        
    </type-mapping>
    
    <table-filter match-name="BULLSHIT_TABLE" exclude="true" />
    
    <table-filter match-name=".*"  package="medattest.model" />
    
</hibernate-reverse-engineering>

```


4. Generate Java classes from DB2 

`$ mvn clean generate-sources ` 

see target/generated-sources/  

---

How to control the process ?

