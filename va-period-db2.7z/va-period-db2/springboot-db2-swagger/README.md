# demo : Périodes VA - Rest Service

$ mvn17 clean install
$ mvn17 spring-boot:run

$ curl -X 'GET' -H 'accept: application/json' 'http://localhost:8080/va/periods?taxYear=2024&taxYearType=SPEC&balanceDate=2024-07-31&amount=1500&paymentDate=2024-02-02'

{
"amount": 1500.00,
"paymentDate": "2024-02-02",
"vaPeriod": "VA_PERIOD_2",
"vaMaxDate": "2024-02-13",
"yearType": "SPEC"
}

Swagger-UI
http://localhost:8080/swagger-ui/index.html#/


https://www.geeksforgeeks.org/spring-boot-jpa-native-query-with-example/
