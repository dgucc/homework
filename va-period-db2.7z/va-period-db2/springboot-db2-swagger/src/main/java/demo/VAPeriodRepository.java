package demo;

import java.math.BigDecimal;
import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface VAPeriodRepository extends JpaRepository<VAPeriodResponse, VAPeriodId> {

    @Query(value="CALL CALCISOC_QT.GET_VA_PERIOD(:taxYear,:taxYearType,:balanceDate,:amount,:paymentDate);", nativeQuery=true)
    VAPeriodResponse getVAPeriod(
        @Param("taxYear") int taxYear, 
        @Param("taxYearType") String taxYearType,
        @Param("balanceDate") Date balanceDate,
        @Param("amount") BigDecimal amount, 
        @Param("paymentDate") Date paymentDate
    );

}
