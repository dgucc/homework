package demo;

import java.math.BigDecimal;
import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VAPeriodService {

    @Autowired
    private VAPeriodRepository vAPeriodRepository;

    public VAPeriodResponse getVAPeriodForPayment(
            int taxYear,
            String taxYearType,
            Date balanceDate,
            BigDecimal amount,
            Date paymentDate){

        return vAPeriodRepository.getVAPeriod(taxYear, taxYearType, balanceDate, amount, paymentDate);
    }
}
