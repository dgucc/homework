package demo;

import java.util.Date;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(schema="CALCISOC_QT",name="VA_PERIOD")
public class VAPeriod {

//   @Id
//   @GeneratedValue(strategy=GenerationType.IDENTITY)
//   @Column(name="ID", nullable = false)
//   private long id;
   @EmbeddedId
   private VAPeriodId vaPeriodId;

//   private int taxYear;
//   private String taxYearType;
//   private int yearOfBalance;
//   private int monthOfBalance;

   @Column(name="D_I_DATE_VA1",nullable = true)
   private Date dateVA1;

   @Column(name="D_I_DATE_VA2", nullable = false)
   private Date dateVA2;
   
   @Column(name="D_I_DATE_VA3", nullable = false)
   private Date dateVA3;
   
   @Column(name="D_I_DATE_VA4", nullable = false)
   private Date dateVA4;
  

}
