package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.Parameter;

import java.math.BigDecimal;
import java.sql.Date;

@RestController
public class VAPeriodControler {


    @Autowired
    private VAPeriodService service;

    @ApiOperation(value = "Get the relevent AP period for a given balanceDate and advancedPaymentDate", notes = "notes...")
    @GetMapping("/va/periods")
    public VAPeriodResponse getVAPeriodForPayment(
        @Parameter(description="Tax Year")
        @RequestParam(value="taxYear", required=true) int taxYear,
        @Parameter(description="Tax Year Type [NORM,SPEC]")
        @RequestParam(value="taxYearType", required=true) String taxYearType,
        @Parameter(description="Balance Date [yyyy-MM-dd]")
        @RequestParam(value="balanceDate", required = true) Date balanceDate,
        @Parameter(description="Amount [yyyy-MM-dd]")
        @RequestParam(value="amount", required = true) BigDecimal amount,
        @Parameter(description="Advance Payment Date [yyyy-MM-dd]")
        @RequestParam(value="paymentDate", required = true) Date paymentDate){

            return service.getVAPeriodForPayment(taxYear, taxYearType, balanceDate, amount, paymentDate);
    }

}
