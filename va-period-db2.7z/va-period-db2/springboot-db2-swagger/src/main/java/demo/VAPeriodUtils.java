package demo;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class VAPeriodUtils {

   public static void main(String[] args) {

       System.out.println("[DEBUTEXER 2022-01-01; DATEBILAN 2022-12-31] isTaxYearAtLeastOneYear() : " + isTaxYearAtLeastOneYear(
         LocalDate.of(2022, 12, 31), // DATEBILAN
         LocalDate.of(2022, 01, 01)  // DEBUTEXER
       ));

       System.out.println("[DEBUTEXER 2022-01-01; DATEBILAN 2022-06-30] isTaxYearAtLeastOneYear() : " + isTaxYearAtLeastOneYear(
         LocalDate.of(2022, 01, 01), // DEBUTEXER
         LocalDate.of(2022, 06, 30)  // DATEBILAN
       ));

       System.out.println("[DEBUTEXER 2022-01-15; DATEBILAN 2022-06-30] getMnd() : " + getMnd(
         LocalDate.of(2022, 06, 30), // DATEBILAN
         LocalDate.of(2022, 01, 15) // DEBUTEXER
       ));
       
       System.out.println("[DEBUTEXER 2022-01-01; DATEBILAN 2022-06-30] getMnd() : " + getMnd(
          LocalDate.of(2022, 06, 30), // DATEBILAN
          LocalDate.of(2022, 01, 01) // DEBUTEXER
         ));
          
      System.out.println("[MND=5] getFictiveMnd() : " + getFictiveMnd(5));
      
      System.out.println("[DATEBILAN 2022-06-30] getFictiveBalanceDate() : " + getFictiveBalanceDate(
         LocalDate.of(2022, 06, 30)
      ));

      System.out.println("[MND=5] getTri() : " + getTri(5));
   }
/*
 * Output :
 * [2022-01-01; 2022-12-31] isTaxYearAtLeastOneYear() : true
 * [2022-01-01; 2022-06-30] isTaxYearAtLeastOneYear() : false
 * [2022-01-15; 2022-06-30] getMnd() : 5
 * [2022-01-01; 2022-06-30] getMnd() : 6
 * [MND=5] getFictiveMnd() : 6
 * [DATEBILAN 2022-06-30] getFictiveBalanceDate() : 2022-07-31
 * [MND=5] getTri() : 34
 */


   public static LocalDate addDays(LocalDate date, int days) {
      return date.plusDays(days);
   }

   public static LocalDate addYears(LocalDate date, int years) {
      return date.plusYears(years);
   }

   public static LocalDate addMonths(LocalDate date, int months) {
      return date.plusMonths(months);
   }

   public static long monthsBetween(LocalDate balanceDate, LocalDate startFiscalYear) {
      return ChronoUnit.MONTHS.between(startFiscalYear, balanceDate);
   }

   public static boolean isTaxYearAtLeastOneYear(LocalDate balanceDate, LocalDate startFiscalYear){
      boolean result = false;
      result = addYears(startFiscalYear,1).isBefore(addDays(balanceDate, 1)) || addYears(startFiscalYear,1).isEqual(addDays(balanceDate, 1));
      return result;
   }

   public static long getMnd(LocalDate balanceDate, LocalDate startFiscalYear){
      long result = 0;
      result = Math.abs(monthsBetween(balanceDate, startFiscalYear));
      if(startFiscalYear.getDayOfMonth() == 1) {
         result = result + 1;
      }
      return result;
   }

   public static long getFictiveMnd(long mnd){
      return Math.floorDiv(mnd+2, 3) * 3;
   }

   public static LocalDate getFictiveBalanceDate(LocalDate balanceDate){
      return addDays(addMonths(balanceDate, 1), 1);
   }

   public static String getTri(long mnd){
      double result = Math.floor((mnd + 2) / 3.0); 

        String tri;
        if (result == 1) {
            tri = "4";
        } else if (result == 2) {
            tri = "34";
        } else if (result == 3) {
            tri = "234";
        } else {
            tri = "";
        }

        return tri;
   }


}
