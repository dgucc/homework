package demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class VAPeriodResponse{
   @Id
   @Column(name="VA_AMOUNT", nullable = false)
   private BigDecimal amount;
   @Column(name="PAYMENT_DATE")
   private Date paymentDate;
   @Column(name="VA_PERIOD")
   private String vaPeriod;
   @Column(name="VA_DATE")
   private Date vaMaxDate;
   @Column(name="TYPE")
   private String yearType;
}

